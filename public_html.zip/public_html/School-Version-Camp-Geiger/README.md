# School-Version-Camp-Geiger
This applications purpose is to provide a student with all of the times and locations of activities for Camp Geiger BSA. In an effort to reduce stress on Teachers having to tell the students where everything is located. This application will help the students to be self sufficient in finding the activities that they want to attend.

# Items Used for Project:
- Bootstrap
- PHP
- JQuery
- MySQL

# Items used purpose:
- Bootstrap
    - Bootstrap is used for styling the page and aligning items properly, not only for desktop but also for mobile devices.
- PHP
    - PHP is used for accessing the MySQL database and is in turn used to produce JSON filled with the data from the database.
- JQuery 
    - The JQuery in this project is fetching the JSON that is produced from the PHP file and then creates the HTML items that are then added to the `<body>` of the Index.html file.
- MySQL
    - The MySQL database is used to store all the information that the PHP file outputs as JSON.

# Use Case:
Scenario: The student needs to know where an activity is located
- Given: A student needs to find an activity location and time.
- When: The student visits the Camp Geiger website.
- Then: The application will show the student all of the locations for all of the activities.