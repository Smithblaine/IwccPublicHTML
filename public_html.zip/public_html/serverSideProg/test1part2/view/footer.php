<footer>
    <p class="copyright">
        &copy; <?php echo date("Y"); ?> Iowa Community College, IWCC.
    </p>
</footer>
</body>
</html>