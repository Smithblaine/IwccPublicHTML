    <main>
        <h1>Customer Search</h1>
        <section>
            <div id="customwrapper">
                <div id="customs">
                    <form action="index.php" method="post" id="search_form">
                        <input type="hidden" name="action" value="search_last">
                        <label>Last Name:</label>
                        <input type="text" name="lastName" />
                        <input type="submit" value="Search">
                    </form>
                </div>
            </div>
        </section>
    </main>
